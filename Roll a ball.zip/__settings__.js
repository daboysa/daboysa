window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "1868770.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
window.SCRIPTS = [ 151938879, 151938889, 151938875, 151938878, 151963905 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: true,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/151938871/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/151938900/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/151938882/1/ammo.js', 'preload' : true},
];
